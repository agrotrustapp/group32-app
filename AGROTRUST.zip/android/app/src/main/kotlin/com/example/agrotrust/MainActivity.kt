package com.example.agrotrust

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
